// سيتم نسخ الكود الكامل من ملفك الحالي (Naram Pos Full Ar)
// يمكنك استبدال هذا الملف بمحتوى الكود الكامل لاحقًا.
import React from 'react';
export default function App(){return <div className='p-8 text-center'>مرحباً بك في نظام نَرام POS. استبدل هذا الملف لاحقاً بالكود الكامل.</div>}
